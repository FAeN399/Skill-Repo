# Contributing to Skill Forge

Thank you for your interest in contributing to Skill Forge! This document provides guidelines and information for contributors.

## 🎯 Ways to Contribute

- **Report bugs** - Found an issue? Let us know!
- **Suggest features** - Have ideas for improvements?
- **Submit skills** - Share your useful skills with the community
- **Improve documentation** - Help others understand the project better
- **Write code** - Fix bugs or implement new features

## 🚀 Getting Started

### Development Setup

1. Fork and clone the repository:
```bash
git clone https://github.com/yourusername/skill-forge.git
cd skill-forge
```

2. Install in development mode:
```bash
pip install -e ".[dev]"
```

3. Run tests to ensure everything works:
```bash
pytest tests/
```

### Project Structure

```
skill-forge/
├── scripts/           # Core CLI tools
│   ├── init_skill.py
│   ├── package_skill.py
│   └── forge.py
├── templates/         # Skill templates
├── examples/          # Example skills
├── docs/             # Documentation
├── tests/            # Test suite
└── .github/          # GitHub workflows
```

## 📝 Contribution Guidelines

### Code Style

We use standard Python tooling:

- **Formatter**: `black` for consistent code formatting
- **Linter**: `ruff` for code quality checks
- **Type hints**: `mypy` for type checking

Run before committing:
```bash
black .
ruff check .
mypy scripts/
```

### Commit Messages

Follow conventional commits format:

```
type(scope): brief description

[optional body]

[optional footer]
```

Types:
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation changes
- `style`: Code style changes (formatting, etc.)
- `refactor`: Code refactoring
- `test`: Adding or updating tests
- `chore`: Maintenance tasks

Examples:
```
feat(forge): add interactive wizard for skill creation
fix(package): handle missing frontmatter gracefully
docs(readme): update installation instructions
```

### Pull Request Process

1. **Create a feature branch**:
   ```bash
   git checkout -b feature/your-feature-name
   ```

2. **Make your changes**:
   - Write clear, concise code
   - Add tests for new functionality
   - Update documentation as needed

3. **Test your changes**:
   ```bash
   pytest tests/
   black .
   ruff check .
   ```

4. **Commit your changes**:
   ```bash
   git add .
   git commit -m "feat: add amazing feature"
   ```

5. **Push and create PR**:
   ```bash
   git push origin feature/your-feature-name
   ```
   Then create a pull request on GitHub.

6. **PR Requirements**:
   - All tests must pass
   - Code must be formatted with black
   - Ruff checks must pass
   - Documentation must be updated
   - PR description clearly explains changes

## 🧪 Testing

### Running Tests

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=scripts tests/

# Run specific test file
pytest tests/test_validation.py

# Run with verbose output
pytest -v
```

### Writing Tests

- Place tests in the `tests/` directory
- Name test files with `test_` prefix
- Use descriptive test function names
- Include docstrings explaining what's being tested

Example:
```python
def test_skill_validation_requires_frontmatter():
    """Ensure validation fails when SKILL.md lacks frontmatter."""
    # Test implementation
```

## 📚 Documentation

### Where to Document

- **README.md** - Project overview and quick start
- **docs/** - Detailed guides and tutorials
- **Code comments** - Complex logic explanations
- **Docstrings** - Function/class documentation

### Documentation Style

- Use clear, concise language
- Include examples where helpful
- Keep it up-to-date with code changes
- Use proper markdown formatting

## 🎨 Submitting Skills

Want to share a skill you've created? Great!

### Skill Submission Guidelines

1. **Quality Requirements**:
   - SKILL.md must pass validation
   - Description must be clear and detailed
   - No TODO placeholders in release version
   - Resources properly organized

2. **Submission Process**:
   - Create skill in `examples/` directory
   - Ensure it follows best practices
   - Test thoroughly with real examples
   - Submit PR with skill and documentation

3. **Skill Criteria**:
   - Solves a real problem
   - Is reusable by others
   - Well-documented with examples
   - Follows Skill Forge standards

## 🐛 Reporting Bugs

### Before Reporting

1. Check existing issues
2. Ensure you're using the latest version
3. Try to reproduce the bug

### Bug Report Template

```markdown
**Description**
Clear description of the bug

**To Reproduce**
Steps to reproduce:
1. Run command '...'
2. See error

**Expected Behavior**
What should have happened

**Environment**
- OS: [e.g., macOS 13.0]
- Python version: [e.g., 3.10]
- Skill Forge version: [e.g., 1.0.0]

**Additional Context**
Any other relevant information
```

## 💡 Feature Requests

We love new ideas! When suggesting features:

1. **Check existing issues** - It might already be planned
2. **Describe the use case** - Why is this needed?
3. **Propose a solution** - How might it work?
4. **Consider alternatives** - Are there other approaches?

## 🔧 Development Tips

### Local Testing

Test your changes with real skills:
```bash
# Create a test skill
python scripts/init_skill.py test-skill --path /tmp

# Validate it
python scripts/forge.py validate /tmp/test-skill

# Package it
python scripts/package_skill.py /tmp/test-skill
```

### Debugging

Use verbose output:
```bash
python -v scripts/forge.py validate /path/to/skill
```

Add print statements or use debugger:
```python
import pdb; pdb.set_trace()
```

## 📄 License

By contributing, you agree that your contributions will be licensed under the MIT License.

## 🤝 Code of Conduct

### Our Standards

- Be respectful and inclusive
- Welcome newcomers
- Accept constructive criticism
- Focus on what's best for the community
- Show empathy towards others

### Unacceptable Behavior

- Harassment or discrimination
- Trolling or insulting comments
- Personal or political attacks
- Publishing others' private information
- Other unprofessional conduct

## 📞 Getting Help

- **Questions**: Open a GitHub Discussion
- **Issues**: Create a GitHub Issue
- **Chat**: Join our Discord (if applicable)

## 🙏 Recognition

Contributors will be:
- Listed in CONTRIBUTORS.md
- Mentioned in release notes
- Credited in documentation (for significant contributions)

---

Thank you for contributing to Skill Forge! Your efforts help make Claude more capable and accessible to everyone. 🎉
