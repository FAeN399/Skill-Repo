# Greeting Guidelines

This reference document demonstrates how to structure reference materials that Claude loads as needed.

## Best Practices for Greetings

### Contextual Awareness

Effective greetings should consider:
- **Time of day** - Morning, afternoon, or evening
- **Formality level** - Professional vs. casual context
- **Cultural context** - Different cultures have different norms
- **Relationship** - First meeting vs. familiar contact

### Common Greeting Patterns

**Formal contexts:**
- "Good morning/afternoon/evening, [Name]"
- "Hello, [Name]. It's a pleasure to meet you."
- "Welcome, [Name]."

**Casual contexts:**
- "Hi [Name]!"
- "Hey there, [Name]!"
- "What's up, [Name]?"

**Professional contexts:**
- "Good [time of day], [Name]."
- "Hello [Name], thank you for joining."
- "Welcome to [context], [Name]."

### Personalization Elements

Greetings become more engaging with:
1. **Name usage** - Personal connection
2. **Time reference** - Temporal awareness
3. **Context mention** - Relevant to situation
4. **Warmth markers** - Friendly tone (emojis, exclamations)

### Cultural Considerations

Different cultures have different greeting norms:
- **Western cultures** - Direct, friendly, name usage
- **Eastern cultures** - Formal, respectful, hierarchy-aware
- **Middle Eastern cultures** - Warm, extended greetings
- **Nordic cultures** - Brief, functional greetings

### Anti-Patterns

Avoid these greeting mistakes:
- ❌ Generic "Dear Sir/Madam" (impersonal)
- ❌ Overly familiar with new contacts
- ❌ Forgetting or misspelling names
- ❌ Ignoring cultural context
- ❌ Being too formal in casual settings
- ❌ Being too casual in formal settings

## Implementation Notes

When implementing greeting logic:
- Use time-based conditionals for time-of-day greetings
- Support customization (name, formality level)
- Handle edge cases (empty names, special characters)
- Consider internationalization for global use

## Progressive Disclosure Example

This file demonstrates progressive disclosure - it contains detailed information that:
- Isn't loaded unless Claude needs it
- Keeps SKILL.md lean and focused
- Provides deep context when required
- Reduces unnecessary context window usage

Claude will read this file only when working with greeting-related tasks that need this level of detail.
